﻿using DMX512;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LightController.Ast
{
	public class DBWrapper
	{
		private IList<DB_Light> lightList;
		private IList<DB_StepCount> stepCountList;
		private IList<DB_Value> valueList;

		public DBWrapper(IList<DB_Light> lightList, IList<DB_StepCount> stepCountList, IList<DB_Value> valueList)
		{
			this.lightList = lightList;
			this.stepCountList = stepCountList;
			this.valueList = valueList;
		}
	}
}
