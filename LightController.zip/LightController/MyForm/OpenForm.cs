﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LightController.MyForm
{
	public partial class OpenForm : Form
	{
		private MainForm mainForm;
		public OpenForm(MainForm mainForm)
		{
			InitializeComponent();
			this.mainForm = mainForm;

			string path = @"C:\Temp\LightProject";
			if (Directory.Exists(path))
			{
				string[] dirs = Directory.GetDirectories(path);
				foreach (string dir in dirs)
				{
					DirectoryInfo di = new DirectoryInfo(dir);
					TreeNode treeNode = new TreeNode(di.Name);

					////由ini文件生成子节点
					//FileInfo[] files = di.GetFiles();
					//foreach (FileInfo file in files)
					//{
					//	string fileName = file.Name;
					//	if (fileName.EndsWith(".ini"))
					//	{
					//		TreeNode node = new TreeNode(
					//			fileName.Substring(0, fileName.IndexOf("."))
					//		);
					//		treeNode.Nodes.Add(node);
					//	}
					//}

					this.treeView1.Nodes.Add(treeNode);
				}
			}
		}

		private void cancelButton_Click(object sender, EventArgs e)
		{
			this.Dispose();
		}

		private void enterButton_Click(object sender, EventArgs e)
		{
			string s =  treeView1.SelectedNode.Text;
			MessageBox.Show("Dickov:" + s);

			//if (!String.IsNullOrEmpty(s))
			//{
			//	string directoryPath = "C:\\Temp\\LightProject\\" + s;
			//	DirectoryInfo di = new DirectoryInfo(directoryPath);
			//	if (di.Exists)
			//	{
			//		MessageBox.Show("这个名称已经被使用了，请使用其他名称。");
			//		return;
			//	}
			//	else
			//	{
			//		// 1.由新建时取的项目名，来新建相关文件夹
			//		di.Create();
			//		// 2.将相关global.ini和data.db3拷贝到文件夹内
			//		string sourcePath = Application.StartupPath;
			//		string dbFilePath = directoryPath + @"\data.db3";
			//		string globalIniFilePath = directoryPath + @"\global.ini";

			//		File.Copy(sourcePath + @"\global.ini", globalIniFilePath);

			//		// 添加密码 -- 正式使用时添加，测试时就不要加了。
			//		// SQLiteHelper.SetPassword(dbFile);

			//		mainForm.BuildProject(globalIniFilePath, dbFilePath, s);
			//		MessageBox.Show("成功新建项目");
			//		this.Dispose();
			//	}
			//}
			//else
			//{
			//	MessageBox.Show("请输入项目名");
			//	return;
			//}
		}
	}
}
