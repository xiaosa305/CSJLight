﻿namespace LightController.MyForm
{
	partial class GlobalSetForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dmxGroupBox = new System.Windows.Forms.GroupBox();
			this.skGroupBox = new System.Windows.Forms.GroupBox();
			this.skSaveButton = new System.Windows.Forms.Button();
			this.label33 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label32 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label31 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.skComboBox24 = new System.Windows.Forms.ComboBox();
			this.skComboBox12 = new System.Windows.Forms.ComboBox();
			this.skComboBox23 = new System.Windows.Forms.ComboBox();
			this.skComboBox11 = new System.Windows.Forms.ComboBox();
			this.skComboBox22 = new System.Windows.Forms.ComboBox();
			this.skComboBox10 = new System.Windows.Forms.ComboBox();
			this.skComboBox21 = new System.Windows.Forms.ComboBox();
			this.skComboBox9 = new System.Windows.Forms.ComboBox();
			this.skComboBox20 = new System.Windows.Forms.ComboBox();
			this.skComboBox8 = new System.Windows.Forms.ComboBox();
			this.skComboBox19 = new System.Windows.Forms.ComboBox();
			this.skComboBox7 = new System.Windows.Forms.ComboBox();
			this.skComboBox18 = new System.Windows.Forms.ComboBox();
			this.skComboBox6 = new System.Windows.Forms.ComboBox();
			this.skComboBox17 = new System.Windows.Forms.ComboBox();
			this.skComboBox5 = new System.Windows.Forms.ComboBox();
			this.skComboBox16 = new System.Windows.Forms.ComboBox();
			this.skComboBox4 = new System.Windows.Forms.ComboBox();
			this.skComboBox15 = new System.Windows.Forms.ComboBox();
			this.skComboBox3 = new System.Windows.Forms.ComboBox();
			this.skComboBox14 = new System.Windows.Forms.ComboBox();
			this.skComboBox2 = new System.Windows.Forms.ComboBox();
			this.skComboBox13 = new System.Windows.Forms.ComboBox();
			this.skComboBox1 = new System.Windows.Forms.ComboBox();
			this.zuheGroupBox = new System.Windows.Forms.GroupBox();
			this.frameSaveButton = new System.Windows.Forms.Button();
			this.zuheFrameComboBox = new System.Windows.Forms.ComboBox();
			this.zuheCheckBox = new System.Windows.Forms.CheckBox();
			this.zuheEnableGroupBox = new System.Windows.Forms.GroupBox();
			this.frame4methodComboBox = new System.Windows.Forms.ComboBox();
			this.frame3methodComboBox = new System.Windows.Forms.ComboBox();
			this.frame2methodComboBox = new System.Windows.Forms.ComboBox();
			this.frame1methodComboBox = new System.Windows.Forms.ComboBox();
			this.frame0numericUpDown = new System.Windows.Forms.NumericUpDown();
			this.label34 = new System.Windows.Forms.Label();
			this.frame4numericUpDown = new System.Windows.Forms.NumericUpDown();
			this.frame3numericUpDown = new System.Windows.Forms.NumericUpDown();
			this.frame2numericUpDown = new System.Windows.Forms.NumericUpDown();
			this.frame4ComboBox = new System.Windows.Forms.ComboBox();
			this.frame3ComboBox = new System.Windows.Forms.ComboBox();
			this.frame2ComboBox = new System.Windows.Forms.ComboBox();
			this.frame1ComboBox = new System.Windows.Forms.ComboBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label35 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.frame1numericUpDown = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.circleTimeNumericUpDown = new System.Windows.Forms.NumericUpDown();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.globalSaveButton = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.startupComboBox = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.tongdaoCountComboBox = new System.Windows.Forms.ComboBox();
			this.qdGroupBox = new System.Windows.Forms.GroupBox();
			this.qdSaveButton = new System.Windows.Forms.Button();
			this.checkBox8 = new System.Windows.Forms.CheckBox();
			this.checkBox7 = new System.Windows.Forms.CheckBox();
			this.checkBox6 = new System.Windows.Forms.CheckBox();
			this.checkBox5 = new System.Windows.Forms.CheckBox();
			this.checkBox4 = new System.Windows.Forms.CheckBox();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.qdFrameComboBox = new System.Windows.Forms.ComboBox();
			this.label36 = new System.Windows.Forms.Label();
			this.frame0methodComboBox = new System.Windows.Forms.ComboBox();
			this.dmxGroupBox.SuspendLayout();
			this.skGroupBox.SuspendLayout();
			this.zuheGroupBox.SuspendLayout();
			this.zuheEnableGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.frame0numericUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.frame4numericUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.frame3numericUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.frame2numericUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.frame1numericUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.circleTimeNumericUpDown)).BeginInit();
			this.groupBox7.SuspendLayout();
			this.qdGroupBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// dmxGroupBox
			// 
			this.dmxGroupBox.AutoSize = true;
			this.dmxGroupBox.Controls.Add(this.skGroupBox);
			this.dmxGroupBox.Controls.Add(this.zuheGroupBox);
			this.dmxGroupBox.Controls.Add(this.groupBox7);
			this.dmxGroupBox.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.dmxGroupBox.Location = new System.Drawing.Point(0, 126);
			this.dmxGroupBox.Name = "dmxGroupBox";
			this.dmxGroupBox.Size = new System.Drawing.Size(926, 605);
			this.dmxGroupBox.TabIndex = 0;
			this.dmxGroupBox.TabStop = false;
			this.dmxGroupBox.Text = "DMX512设置";
			// 
			// skGroupBox
			// 
			this.skGroupBox.Controls.Add(this.skSaveButton);
			this.skGroupBox.Controls.Add(this.label33);
			this.skGroupBox.Controls.Add(this.label21);
			this.skGroupBox.Controls.Add(this.label32);
			this.skGroupBox.Controls.Add(this.label17);
			this.skGroupBox.Controls.Add(this.label31);
			this.skGroupBox.Controls.Add(this.label13);
			this.skGroupBox.Controls.Add(this.label30);
			this.skGroupBox.Controls.Add(this.label20);
			this.skGroupBox.Controls.Add(this.label29);
			this.skGroupBox.Controls.Add(this.label16);
			this.skGroupBox.Controls.Add(this.label28);
			this.skGroupBox.Controls.Add(this.label12);
			this.skGroupBox.Controls.Add(this.label27);
			this.skGroupBox.Controls.Add(this.label19);
			this.skGroupBox.Controls.Add(this.label26);
			this.skGroupBox.Controls.Add(this.label15);
			this.skGroupBox.Controls.Add(this.label25);
			this.skGroupBox.Controls.Add(this.label11);
			this.skGroupBox.Controls.Add(this.label24);
			this.skGroupBox.Controls.Add(this.label18);
			this.skGroupBox.Controls.Add(this.label23);
			this.skGroupBox.Controls.Add(this.label14);
			this.skGroupBox.Controls.Add(this.label22);
			this.skGroupBox.Controls.Add(this.label10);
			this.skGroupBox.Controls.Add(this.skComboBox24);
			this.skGroupBox.Controls.Add(this.skComboBox12);
			this.skGroupBox.Controls.Add(this.skComboBox23);
			this.skGroupBox.Controls.Add(this.skComboBox11);
			this.skGroupBox.Controls.Add(this.skComboBox22);
			this.skGroupBox.Controls.Add(this.skComboBox10);
			this.skGroupBox.Controls.Add(this.skComboBox21);
			this.skGroupBox.Controls.Add(this.skComboBox9);
			this.skGroupBox.Controls.Add(this.skComboBox20);
			this.skGroupBox.Controls.Add(this.skComboBox8);
			this.skGroupBox.Controls.Add(this.skComboBox19);
			this.skGroupBox.Controls.Add(this.skComboBox7);
			this.skGroupBox.Controls.Add(this.skComboBox18);
			this.skGroupBox.Controls.Add(this.skComboBox6);
			this.skGroupBox.Controls.Add(this.skComboBox17);
			this.skGroupBox.Controls.Add(this.skComboBox5);
			this.skGroupBox.Controls.Add(this.skComboBox16);
			this.skGroupBox.Controls.Add(this.skComboBox4);
			this.skGroupBox.Controls.Add(this.skComboBox15);
			this.skGroupBox.Controls.Add(this.skComboBox3);
			this.skGroupBox.Controls.Add(this.skComboBox14);
			this.skGroupBox.Controls.Add(this.skComboBox2);
			this.skGroupBox.Controls.Add(this.skComboBox13);
			this.skGroupBox.Controls.Add(this.skComboBox1);
			this.skGroupBox.Location = new System.Drawing.Point(7, 373);
			this.skGroupBox.Name = "skGroupBox";
			this.skGroupBox.Size = new System.Drawing.Size(916, 208);
			this.skGroupBox.TabIndex = 2;
			this.skGroupBox.TabStop = false;
			this.skGroupBox.Text = "声控场景触发步数设置";
			// 
			// skSaveButton
			// 
			this.skSaveButton.BackColor = System.Drawing.Color.LightSalmon;
			this.skSaveButton.Location = new System.Drawing.Point(794, 178);
			this.skSaveButton.Name = "skSaveButton";
			this.skSaveButton.Size = new System.Drawing.Size(93, 28);
			this.skSaveButton.TabIndex = 3;
			this.skSaveButton.Text = "保存设置";
			this.skSaveButton.UseVisualStyleBackColor = false;
			this.skSaveButton.Click += new System.EventHandler(this.skSaveButton_Click);
			// 
			// label33
			// 
			this.label33.AutoSize = true;
			this.label33.Location = new System.Drawing.Point(831, 104);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(37, 15);
			this.label33.TabIndex = 1;
			this.label33.Text = "倒彩";
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(831, 36);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(37, 15);
			this.label21.TabIndex = 1;
			this.label21.Text = "全关";
			// 
			// label32
			// 
			this.label32.AutoSize = true;
			this.label32.Location = new System.Drawing.Point(539, 104);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(45, 15);
			this.label32.TabIndex = 1;
			this.label32.Text = "备用5";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(539, 36);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(37, 15);
			this.label17.TabIndex = 1;
			this.label17.Text = "明亮";
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Location = new System.Drawing.Point(247, 104);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(45, 15);
			this.label31.TabIndex = 1;
			this.label31.Text = "备用1";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(247, 36);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(37, 15);
			this.label13.TabIndex = 1;
			this.label13.Text = "抒情";
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(758, 104);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(37, 15);
			this.label30.TabIndex = 1;
			this.label30.Text = "喝彩";
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(758, 36);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(37, 15);
			this.label20.TabIndex = 1;
			this.label20.Text = "暂停";
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(466, 104);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(45, 15);
			this.label29.TabIndex = 1;
			this.label29.Text = "备用4";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(466, 36);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(37, 15);
			this.label16.TabIndex = 1;
			this.label16.Text = "激情";
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(174, 104);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(37, 15);
			this.label28.TabIndex = 1;
			this.label28.Text = "电影";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(174, 36);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(37, 15);
			this.label12.TabIndex = 1;
			this.label12.Text = "商务";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(685, 104);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(37, 15);
			this.label27.TabIndex = 1;
			this.label27.Text = "摇麦";
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(685, 36);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(37, 15);
			this.label19.TabIndex = 1;
			this.label19.Text = "演出";
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(393, 104);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(45, 15);
			this.label26.TabIndex = 1;
			this.label26.Text = "备用3";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(393, 36);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(37, 15);
			this.label15.TabIndex = 1;
			this.label15.Text = "柔和";
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(101, 104);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(52, 15);
			this.label25.TabIndex = 1;
			this.label25.Text = "全开关";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(101, 36);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(37, 15);
			this.label11.TabIndex = 1;
			this.label11.Text = "动感";
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(612, 104);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(45, 15);
			this.label24.TabIndex = 1;
			this.label24.Text = "备用6";
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(612, 36);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(37, 15);
			this.label18.TabIndex = 1;
			this.label18.Text = "浪漫";
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(320, 104);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(45, 15);
			this.label23.TabIndex = 1;
			this.label23.Text = "备用2";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(320, 36);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(37, 15);
			this.label14.TabIndex = 1;
			this.label14.Text = "清洁";
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(28, 104);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(37, 15);
			this.label22.TabIndex = 1;
			this.label22.Text = "全开";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(28, 36);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(37, 15);
			this.label10.TabIndex = 1;
			this.label10.Text = "标准";
			// 
			// skComboBox24
			// 
			this.skComboBox24.FormattingEnabled = true;
			this.skComboBox24.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox24.Location = new System.Drawing.Point(823, 134);
			this.skComboBox24.Name = "skComboBox24";
			this.skComboBox24.Size = new System.Drawing.Size(56, 23);
			this.skComboBox24.TabIndex = 0;
			// 
			// skComboBox12
			// 
			this.skComboBox12.FormattingEnabled = true;
			this.skComboBox12.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox12.Location = new System.Drawing.Point(823, 63);
			this.skComboBox12.Name = "skComboBox12";
			this.skComboBox12.Size = new System.Drawing.Size(56, 23);
			this.skComboBox12.TabIndex = 0;
			// 
			// skComboBox23
			// 
			this.skComboBox23.FormattingEnabled = true;
			this.skComboBox23.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox23.Location = new System.Drawing.Point(750, 134);
			this.skComboBox23.Name = "skComboBox23";
			this.skComboBox23.Size = new System.Drawing.Size(56, 23);
			this.skComboBox23.TabIndex = 0;
			// 
			// skComboBox11
			// 
			this.skComboBox11.FormattingEnabled = true;
			this.skComboBox11.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox11.Location = new System.Drawing.Point(750, 63);
			this.skComboBox11.Name = "skComboBox11";
			this.skComboBox11.Size = new System.Drawing.Size(56, 23);
			this.skComboBox11.TabIndex = 0;
			// 
			// skComboBox22
			// 
			this.skComboBox22.FormattingEnabled = true;
			this.skComboBox22.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox22.Location = new System.Drawing.Point(677, 134);
			this.skComboBox22.Name = "skComboBox22";
			this.skComboBox22.Size = new System.Drawing.Size(56, 23);
			this.skComboBox22.TabIndex = 0;
			// 
			// skComboBox10
			// 
			this.skComboBox10.FormattingEnabled = true;
			this.skComboBox10.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox10.Location = new System.Drawing.Point(677, 63);
			this.skComboBox10.Name = "skComboBox10";
			this.skComboBox10.Size = new System.Drawing.Size(56, 23);
			this.skComboBox10.TabIndex = 0;
			// 
			// skComboBox21
			// 
			this.skComboBox21.FormattingEnabled = true;
			this.skComboBox21.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox21.Location = new System.Drawing.Point(604, 134);
			this.skComboBox21.Name = "skComboBox21";
			this.skComboBox21.Size = new System.Drawing.Size(56, 23);
			this.skComboBox21.TabIndex = 0;
			// 
			// skComboBox9
			// 
			this.skComboBox9.FormattingEnabled = true;
			this.skComboBox9.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox9.Location = new System.Drawing.Point(604, 63);
			this.skComboBox9.Name = "skComboBox9";
			this.skComboBox9.Size = new System.Drawing.Size(56, 23);
			this.skComboBox9.TabIndex = 0;
			// 
			// skComboBox20
			// 
			this.skComboBox20.FormattingEnabled = true;
			this.skComboBox20.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox20.Location = new System.Drawing.Point(528, 134);
			this.skComboBox20.Name = "skComboBox20";
			this.skComboBox20.Size = new System.Drawing.Size(56, 23);
			this.skComboBox20.TabIndex = 0;
			// 
			// skComboBox8
			// 
			this.skComboBox8.FormattingEnabled = true;
			this.skComboBox8.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox8.Location = new System.Drawing.Point(528, 63);
			this.skComboBox8.Name = "skComboBox8";
			this.skComboBox8.Size = new System.Drawing.Size(56, 23);
			this.skComboBox8.TabIndex = 0;
			// 
			// skComboBox19
			// 
			this.skComboBox19.FormattingEnabled = true;
			this.skComboBox19.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox19.Location = new System.Drawing.Point(458, 134);
			this.skComboBox19.Name = "skComboBox19";
			this.skComboBox19.Size = new System.Drawing.Size(56, 23);
			this.skComboBox19.TabIndex = 0;
			// 
			// skComboBox7
			// 
			this.skComboBox7.FormattingEnabled = true;
			this.skComboBox7.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox7.Location = new System.Drawing.Point(458, 63);
			this.skComboBox7.Name = "skComboBox7";
			this.skComboBox7.Size = new System.Drawing.Size(56, 23);
			this.skComboBox7.TabIndex = 0;
			// 
			// skComboBox18
			// 
			this.skComboBox18.FormattingEnabled = true;
			this.skComboBox18.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox18.Location = new System.Drawing.Point(385, 134);
			this.skComboBox18.Name = "skComboBox18";
			this.skComboBox18.Size = new System.Drawing.Size(56, 23);
			this.skComboBox18.TabIndex = 0;
			// 
			// skComboBox6
			// 
			this.skComboBox6.FormattingEnabled = true;
			this.skComboBox6.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox6.Location = new System.Drawing.Point(385, 63);
			this.skComboBox6.Name = "skComboBox6";
			this.skComboBox6.Size = new System.Drawing.Size(56, 23);
			this.skComboBox6.TabIndex = 0;
			// 
			// skComboBox17
			// 
			this.skComboBox17.FormattingEnabled = true;
			this.skComboBox17.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox17.Location = new System.Drawing.Point(312, 134);
			this.skComboBox17.Name = "skComboBox17";
			this.skComboBox17.Size = new System.Drawing.Size(56, 23);
			this.skComboBox17.TabIndex = 0;
			// 
			// skComboBox5
			// 
			this.skComboBox5.FormattingEnabled = true;
			this.skComboBox5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox5.Location = new System.Drawing.Point(312, 63);
			this.skComboBox5.Name = "skComboBox5";
			this.skComboBox5.Size = new System.Drawing.Size(56, 23);
			this.skComboBox5.TabIndex = 0;
			// 
			// skComboBox16
			// 
			this.skComboBox16.FormattingEnabled = true;
			this.skComboBox16.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox16.Location = new System.Drawing.Point(239, 134);
			this.skComboBox16.Name = "skComboBox16";
			this.skComboBox16.Size = new System.Drawing.Size(56, 23);
			this.skComboBox16.TabIndex = 0;
			// 
			// skComboBox4
			// 
			this.skComboBox4.FormattingEnabled = true;
			this.skComboBox4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox4.Location = new System.Drawing.Point(239, 63);
			this.skComboBox4.Name = "skComboBox4";
			this.skComboBox4.Size = new System.Drawing.Size(56, 23);
			this.skComboBox4.TabIndex = 0;
			// 
			// skComboBox15
			// 
			this.skComboBox15.FormattingEnabled = true;
			this.skComboBox15.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox15.Location = new System.Drawing.Point(166, 134);
			this.skComboBox15.Name = "skComboBox15";
			this.skComboBox15.Size = new System.Drawing.Size(56, 23);
			this.skComboBox15.TabIndex = 0;
			// 
			// skComboBox3
			// 
			this.skComboBox3.FormattingEnabled = true;
			this.skComboBox3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox3.Location = new System.Drawing.Point(166, 63);
			this.skComboBox3.Name = "skComboBox3";
			this.skComboBox3.Size = new System.Drawing.Size(56, 23);
			this.skComboBox3.TabIndex = 0;
			// 
			// skComboBox14
			// 
			this.skComboBox14.FormattingEnabled = true;
			this.skComboBox14.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox14.Location = new System.Drawing.Point(92, 134);
			this.skComboBox14.Name = "skComboBox14";
			this.skComboBox14.Size = new System.Drawing.Size(56, 23);
			this.skComboBox14.TabIndex = 0;
			// 
			// skComboBox2
			// 
			this.skComboBox2.FormattingEnabled = true;
			this.skComboBox2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox2.Location = new System.Drawing.Point(92, 63);
			this.skComboBox2.Name = "skComboBox2";
			this.skComboBox2.Size = new System.Drawing.Size(56, 23);
			this.skComboBox2.TabIndex = 0;
			// 
			// skComboBox13
			// 
			this.skComboBox13.FormattingEnabled = true;
			this.skComboBox13.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox13.Location = new System.Drawing.Point(20, 134);
			this.skComboBox13.Name = "skComboBox13";
			this.skComboBox13.Size = new System.Drawing.Size(56, 23);
			this.skComboBox13.TabIndex = 0;
			// 
			// skComboBox1
			// 
			this.skComboBox1.FormattingEnabled = true;
			this.skComboBox1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
			this.skComboBox1.Location = new System.Drawing.Point(20, 63);
			this.skComboBox1.Name = "skComboBox1";
			this.skComboBox1.Size = new System.Drawing.Size(56, 23);
			this.skComboBox1.TabIndex = 0;
			// 
			// zuheGroupBox
			// 
			this.zuheGroupBox.Controls.Add(this.frameSaveButton);
			this.zuheGroupBox.Controls.Add(this.zuheFrameComboBox);
			this.zuheGroupBox.Controls.Add(this.zuheCheckBox);
			this.zuheGroupBox.Controls.Add(this.zuheEnableGroupBox);
			this.zuheGroupBox.Controls.Add(this.label3);
			this.zuheGroupBox.Controls.Add(this.circleTimeNumericUpDown);
			this.zuheGroupBox.Location = new System.Drawing.Point(7, 99);
			this.zuheGroupBox.Name = "zuheGroupBox";
			this.zuheGroupBox.Size = new System.Drawing.Size(916, 256);
			this.zuheGroupBox.TabIndex = 1;
			this.zuheGroupBox.TabStop = false;
			this.zuheGroupBox.Text = "多场景组合播放设置";
			// 
			// frameSaveButton
			// 
			this.frameSaveButton.BackColor = System.Drawing.Color.Linen;
			this.frameSaveButton.Location = new System.Drawing.Point(794, 30);
			this.frameSaveButton.Name = "frameSaveButton";
			this.frameSaveButton.Size = new System.Drawing.Size(93, 28);
			this.frameSaveButton.TabIndex = 3;
			this.frameSaveButton.Text = "保存当前项";
			this.frameSaveButton.UseVisualStyleBackColor = false;
			this.frameSaveButton.Click += new System.EventHandler(this.frameSaveButton_Click);
			// 
			// zuheFrameComboBox
			// 
			this.zuheFrameComboBox.FormattingEnabled = true;
			this.zuheFrameComboBox.Items.AddRange(new object[] {
            "标准",
            "动感",
            "商务",
            "抒情",
            "清洁",
            "柔和",
            "激情",
            "明亮",
            "浪漫"});
			this.zuheFrameComboBox.Location = new System.Drawing.Point(17, 32);
			this.zuheFrameComboBox.Name = "zuheFrameComboBox";
			this.zuheFrameComboBox.Size = new System.Drawing.Size(121, 23);
			this.zuheFrameComboBox.TabIndex = 2;
			this.zuheFrameComboBox.SelectedIndexChanged += new System.EventHandler(this.zuheFrameComboBox_SelectedIndexChanged);
			// 
			// zuheCheckBox
			// 
			this.zuheCheckBox.AutoSize = true;
			this.zuheCheckBox.Location = new System.Drawing.Point(188, 32);
			this.zuheCheckBox.Name = "zuheCheckBox";
			this.zuheCheckBox.Size = new System.Drawing.Size(134, 19);
			this.zuheCheckBox.TabIndex = 1;
			this.zuheCheckBox.Text = "是否开启此功能";
			this.zuheCheckBox.UseVisualStyleBackColor = true;
			this.zuheCheckBox.CheckedChanged += new System.EventHandler(this.zuheCheckBox_CheckedChanged);
			// 
			// zuheEnableGroupBox
			// 
			this.zuheEnableGroupBox.Controls.Add(this.frame0methodComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.label36);
			this.zuheEnableGroupBox.Controls.Add(this.frame4methodComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.frame3methodComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.frame2methodComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.frame1methodComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.frame0numericUpDown);
			this.zuheEnableGroupBox.Controls.Add(this.label34);
			this.zuheEnableGroupBox.Controls.Add(this.frame4numericUpDown);
			this.zuheEnableGroupBox.Controls.Add(this.frame3numericUpDown);
			this.zuheEnableGroupBox.Controls.Add(this.frame2numericUpDown);
			this.zuheEnableGroupBox.Controls.Add(this.frame4ComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.frame3ComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.frame2ComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.frame1ComboBox);
			this.zuheEnableGroupBox.Controls.Add(this.label9);
			this.zuheEnableGroupBox.Controls.Add(this.label7);
			this.zuheEnableGroupBox.Controls.Add(this.label6);
			this.zuheEnableGroupBox.Controls.Add(this.label5);
			this.zuheEnableGroupBox.Controls.Add(this.label35);
			this.zuheEnableGroupBox.Controls.Add(this.label8);
			this.zuheEnableGroupBox.Controls.Add(this.frame1numericUpDown);
			this.zuheEnableGroupBox.Controls.Add(this.label4);
			this.zuheEnableGroupBox.Enabled = false;
			this.zuheEnableGroupBox.Location = new System.Drawing.Point(10, 70);
			this.zuheEnableGroupBox.Name = "zuheEnableGroupBox";
			this.zuheEnableGroupBox.Size = new System.Drawing.Size(895, 176);
			this.zuheEnableGroupBox.TabIndex = 0;
			this.zuheEnableGroupBox.TabStop = false;
			this.zuheEnableGroupBox.Text = "播放设置";
			// 
			// frame4methodComboBox
			// 
			this.frame4methodComboBox.FormattingEnabled = true;
			this.frame4methodComboBox.Items.AddRange(new object[] {
            "固定时间",
            "固定次数"});
			this.frame4methodComboBox.Location = new System.Drawing.Point(747, 90);
			this.frame4methodComboBox.Name = "frame4methodComboBox";
			this.frame4methodComboBox.Size = new System.Drawing.Size(99, 23);
			this.frame4methodComboBox.TabIndex = 7;
			// 
			// frame3methodComboBox
			// 
			this.frame3methodComboBox.FormattingEnabled = true;
			this.frame3methodComboBox.Items.AddRange(new object[] {
            "固定时间",
            "固定次数"});
			this.frame3methodComboBox.Location = new System.Drawing.Point(599, 90);
			this.frame3methodComboBox.Name = "frame3methodComboBox";
			this.frame3methodComboBox.Size = new System.Drawing.Size(99, 23);
			this.frame3methodComboBox.TabIndex = 7;
			// 
			// frame2methodComboBox
			// 
			this.frame2methodComboBox.FormattingEnabled = true;
			this.frame2methodComboBox.Items.AddRange(new object[] {
            "固定时间",
            "固定次数"});
			this.frame2methodComboBox.Location = new System.Drawing.Point(447, 90);
			this.frame2methodComboBox.Name = "frame2methodComboBox";
			this.frame2methodComboBox.Size = new System.Drawing.Size(99, 23);
			this.frame2methodComboBox.TabIndex = 7;
			// 
			// frame1methodComboBox
			// 
			this.frame1methodComboBox.FormattingEnabled = true;
			this.frame1methodComboBox.Items.AddRange(new object[] {
            "固定时间",
            "固定次数"});
			this.frame1methodComboBox.Location = new System.Drawing.Point(295, 90);
			this.frame1methodComboBox.Name = "frame1methodComboBox";
			this.frame1methodComboBox.Size = new System.Drawing.Size(99, 23);
			this.frame1methodComboBox.TabIndex = 7;
			// 
			// frame0numericUpDown
			// 
			this.frame0numericUpDown.Location = new System.Drawing.Point(22, 130);
			this.frame0numericUpDown.Name = "frame0numericUpDown";
			this.frame0numericUpDown.Size = new System.Drawing.Size(116, 25);
			this.frame0numericUpDown.TabIndex = 4;
			this.frame0numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label34
			// 
			this.label34.AutoSize = true;
			this.label34.Location = new System.Drawing.Point(26, 98);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(105, 15);
			this.label34.TabIndex = 5;
			this.label34.Text = "播放时间/次数";
			// 
			// frame4numericUpDown
			// 
			this.frame4numericUpDown.Location = new System.Drawing.Point(747, 126);
			this.frame4numericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
			this.frame4numericUpDown.Name = "frame4numericUpDown";
			this.frame4numericUpDown.Size = new System.Drawing.Size(99, 25);
			this.frame4numericUpDown.TabIndex = 6;
			this.frame4numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// frame3numericUpDown
			// 
			this.frame3numericUpDown.Location = new System.Drawing.Point(599, 126);
			this.frame3numericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
			this.frame3numericUpDown.Name = "frame3numericUpDown";
			this.frame3numericUpDown.Size = new System.Drawing.Size(99, 25);
			this.frame3numericUpDown.TabIndex = 5;
			this.frame3numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// frame2numericUpDown
			// 
			this.frame2numericUpDown.Location = new System.Drawing.Point(447, 126);
			this.frame2numericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
			this.frame2numericUpDown.Name = "frame2numericUpDown";
			this.frame2numericUpDown.Size = new System.Drawing.Size(99, 25);
			this.frame2numericUpDown.TabIndex = 4;
			this.frame2numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// frame4ComboBox
			// 
			this.frame4ComboBox.FormattingEnabled = true;
			this.frame4ComboBox.Items.AddRange(new object[] {
            "标准",
            "动感",
            "商务",
            "抒情",
            "清洁",
            "柔和",
            "激情",
            "明亮",
            "浪漫",
            "演出",
            "暂停",
            "全关",
            "全开",
            "全开关",
            "电影",
            "备用1",
            "备用2",
            "备用3",
            "备用4",
            "备用5",
            "备用6",
            "摇麦",
            "喝彩",
            "倒彩"});
			this.frame4ComboBox.Location = new System.Drawing.Point(747, 51);
			this.frame4ComboBox.Name = "frame4ComboBox";
			this.frame4ComboBox.Size = new System.Drawing.Size(99, 23);
			this.frame4ComboBox.TabIndex = 3;
			// 
			// frame3ComboBox
			// 
			this.frame3ComboBox.FormattingEnabled = true;
			this.frame3ComboBox.Items.AddRange(new object[] {
            "标准",
            "动感",
            "商务",
            "抒情",
            "清洁",
            "柔和",
            "激情",
            "明亮",
            "浪漫",
            "演出",
            "暂停",
            "全关",
            "全开",
            "全开关",
            "电影",
            "备用1",
            "备用2",
            "备用3",
            "备用4",
            "备用5",
            "备用6",
            "摇麦",
            "喝彩",
            "倒彩"});
			this.frame3ComboBox.Location = new System.Drawing.Point(599, 51);
			this.frame3ComboBox.Name = "frame3ComboBox";
			this.frame3ComboBox.Size = new System.Drawing.Size(99, 23);
			this.frame3ComboBox.TabIndex = 3;
			// 
			// frame2ComboBox
			// 
			this.frame2ComboBox.FormattingEnabled = true;
			this.frame2ComboBox.Items.AddRange(new object[] {
            "标准",
            "动感",
            "商务",
            "抒情",
            "清洁",
            "柔和",
            "激情",
            "明亮",
            "浪漫",
            "演出",
            "暂停",
            "全关",
            "全开",
            "全开关",
            "电影",
            "备用1",
            "备用2",
            "备用3",
            "备用4",
            "备用5",
            "备用6",
            "摇麦",
            "喝彩",
            "倒彩"});
			this.frame2ComboBox.Location = new System.Drawing.Point(447, 51);
			this.frame2ComboBox.Name = "frame2ComboBox";
			this.frame2ComboBox.Size = new System.Drawing.Size(99, 23);
			this.frame2ComboBox.TabIndex = 3;
			// 
			// frame1ComboBox
			// 
			this.frame1ComboBox.FormattingEnabled = true;
			this.frame1ComboBox.Items.AddRange(new object[] {
            "标准",
            "动感",
            "商务",
            "抒情",
            "清洁",
            "柔和",
            "激情",
            "明亮",
            "浪漫",
            "演出",
            "暂停",
            "全关",
            "全开",
            "全开关",
            "电影",
            "备用1",
            "备用2",
            "备用3",
            "备用4",
            "备用5",
            "备用6",
            "摇麦",
            "喝彩",
            "倒彩"});
			this.frame1ComboBox.Location = new System.Drawing.Point(295, 51);
			this.frame1ComboBox.Name = "frame1ComboBox";
			this.frame1ComboBox.Size = new System.Drawing.Size(99, 23);
			this.frame1ComboBox.TabIndex = 3;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(185, 55);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(67, 15);
			this.label9.TabIndex = 2;
			this.label9.Text = "场景类型";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(750, 21);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(75, 15);
			this.label7.TabIndex = 1;
			this.label7.Text = "组合场景4";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(598, 21);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(75, 15);
			this.label6.TabIndex = 1;
			this.label6.Text = "组合场景3";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(451, 21);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(75, 15);
			this.label5.TabIndex = 1;
			this.label5.Text = "组合场景2";
			// 
			// label35
			// 
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(185, 131);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(99, 15);
			this.label35.TabIndex = 1;
			this.label35.Text = "时间(s)/次数";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(185, 93);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(67, 15);
			this.label8.TabIndex = 1;
			this.label8.Text = "播放方式";
			// 
			// frame1numericUpDown
			// 
			this.frame1numericUpDown.Location = new System.Drawing.Point(296, 126);
			this.frame1numericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
			this.frame1numericUpDown.Name = "frame1numericUpDown";
			this.frame1numericUpDown.Size = new System.Drawing.Size(98, 25);
			this.frame1numericUpDown.TabIndex = 0;
			this.frame1numericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(294, 21);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(75, 15);
			this.label4.TabIndex = 1;
			this.label4.Text = "组合场景1";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(378, 34);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(97, 15);
			this.label3.TabIndex = 1;
			this.label3.Text = "总循环次数：";
			// 
			// circleTimeNumericUpDown
			// 
			this.circleTimeNumericUpDown.Enabled = false;
			this.circleTimeNumericUpDown.Location = new System.Drawing.Point(481, 30);
			this.circleTimeNumericUpDown.Name = "circleTimeNumericUpDown";
			this.circleTimeNumericUpDown.Size = new System.Drawing.Size(120, 25);
			this.circleTimeNumericUpDown.TabIndex = 0;
			this.circleTimeNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.globalSaveButton);
			this.groupBox7.Controls.Add(this.label2);
			this.groupBox7.Controls.Add(this.startupComboBox);
			this.groupBox7.Controls.Add(this.label1);
			this.groupBox7.Controls.Add(this.tongdaoCountComboBox);
			this.groupBox7.Location = new System.Drawing.Point(7, 25);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(916, 68);
			this.groupBox7.TabIndex = 0;
			this.groupBox7.TabStop = false;
			// 
			// globalSaveButton
			// 
			this.globalSaveButton.BackColor = System.Drawing.Color.Wheat;
			this.globalSaveButton.Location = new System.Drawing.Point(794, 24);
			this.globalSaveButton.Name = "globalSaveButton";
			this.globalSaveButton.Size = new System.Drawing.Size(93, 28);
			this.globalSaveButton.TabIndex = 3;
			this.globalSaveButton.Text = "保存设置";
			this.globalSaveButton.UseVisualStyleBackColor = false;
			this.globalSaveButton.Click += new System.EventHandler(this.globalSaveButton_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(320, 26);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(142, 15);
			this.label2.TabIndex = 3;
			this.label2.Text = "开机自动播放场景：";
			// 
			// startupComboBox
			// 
			this.startupComboBox.FormattingEnabled = true;
			this.startupComboBox.Items.AddRange(new object[] {
            "无",
            "标准",
            "动感",
            "商务",
            "抒情",
            "清洁",
            "柔和",
            "激情",
            "明亮",
            "浪漫",
            "演出",
            "暂停",
            "全关",
            "全开",
            "全开关",
            "电影",
            "备用1",
            "备用2",
            "备用3",
            "备用4",
            "备用5",
            "备用6",
            "摇麦",
            "喝彩",
            "倒彩"});
			this.startupComboBox.Location = new System.Drawing.Point(473, 22);
			this.startupComboBox.Name = "startupComboBox";
			this.startupComboBox.Size = new System.Drawing.Size(138, 23);
			this.startupComboBox.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(28, 26);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 15);
			this.label1.TabIndex = 1;
			this.label1.Text = "通道总数设置：";
			// 
			// tongdaoCountComboBox
			// 
			this.tongdaoCountComboBox.FormattingEnabled = true;
			this.tongdaoCountComboBox.Items.AddRange(new object[] {
            "512",
            "384",
            "256",
            "128"});
			this.tongdaoCountComboBox.Location = new System.Drawing.Point(146, 22);
			this.tongdaoCountComboBox.Name = "tongdaoCountComboBox";
			this.tongdaoCountComboBox.Size = new System.Drawing.Size(138, 23);
			this.tongdaoCountComboBox.TabIndex = 0;
			// 
			// qdGroupBox
			// 
			this.qdGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.qdGroupBox.Controls.Add(this.qdSaveButton);
			this.qdGroupBox.Controls.Add(this.checkBox8);
			this.qdGroupBox.Controls.Add(this.checkBox7);
			this.qdGroupBox.Controls.Add(this.checkBox6);
			this.qdGroupBox.Controls.Add(this.checkBox5);
			this.qdGroupBox.Controls.Add(this.checkBox4);
			this.qdGroupBox.Controls.Add(this.checkBox3);
			this.qdGroupBox.Controls.Add(this.checkBox2);
			this.qdGroupBox.Controls.Add(this.checkBox1);
			this.qdGroupBox.Controls.Add(this.qdFrameComboBox);
			this.qdGroupBox.Location = new System.Drawing.Point(0, 12);
			this.qdGroupBox.Name = "qdGroupBox";
			this.qdGroupBox.Size = new System.Drawing.Size(926, 77);
			this.qdGroupBox.TabIndex = 0;
			this.qdGroupBox.TabStop = false;
			this.qdGroupBox.Text = "智能灯光控制器设置";
			// 
			// qdSaveButton
			// 
			this.qdSaveButton.BackColor = System.Drawing.Color.Cornsilk;
			this.qdSaveButton.Location = new System.Drawing.Point(811, 36);
			this.qdSaveButton.Name = "qdSaveButton";
			this.qdSaveButton.Size = new System.Drawing.Size(93, 28);
			this.qdSaveButton.TabIndex = 2;
			this.qdSaveButton.Text = "保存当前项";
			this.qdSaveButton.UseVisualStyleBackColor = false;
			this.qdSaveButton.Click += new System.EventHandler(this.qdSaveButton_Click);
			// 
			// checkBox8
			// 
			this.checkBox8.AutoSize = true;
			this.checkBox8.Location = new System.Drawing.Point(720, 41);
			this.checkBox8.Name = "checkBox8";
			this.checkBox8.Size = new System.Drawing.Size(67, 19);
			this.checkBox8.TabIndex = 1;
			this.checkBox8.Text = "开关8";
			this.checkBox8.UseVisualStyleBackColor = true;
			// 
			// checkBox7
			// 
			this.checkBox7.AutoSize = true;
			this.checkBox7.Location = new System.Drawing.Point(641, 41);
			this.checkBox7.Name = "checkBox7";
			this.checkBox7.Size = new System.Drawing.Size(67, 19);
			this.checkBox7.TabIndex = 1;
			this.checkBox7.Text = "开关7";
			this.checkBox7.UseVisualStyleBackColor = true;
			// 
			// checkBox6
			// 
			this.checkBox6.AutoSize = true;
			this.checkBox6.Location = new System.Drawing.Point(562, 41);
			this.checkBox6.Name = "checkBox6";
			this.checkBox6.Size = new System.Drawing.Size(67, 19);
			this.checkBox6.TabIndex = 1;
			this.checkBox6.Text = "开关6";
			this.checkBox6.UseVisualStyleBackColor = true;
			// 
			// checkBox5
			// 
			this.checkBox5.AutoSize = true;
			this.checkBox5.Location = new System.Drawing.Point(483, 41);
			this.checkBox5.Name = "checkBox5";
			this.checkBox5.Size = new System.Drawing.Size(67, 19);
			this.checkBox5.TabIndex = 1;
			this.checkBox5.Text = "开关5";
			this.checkBox5.UseVisualStyleBackColor = true;
			// 
			// checkBox4
			// 
			this.checkBox4.AutoSize = true;
			this.checkBox4.Location = new System.Drawing.Point(404, 41);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new System.Drawing.Size(67, 19);
			this.checkBox4.TabIndex = 1;
			this.checkBox4.Text = "开关4";
			this.checkBox4.UseVisualStyleBackColor = true;
			// 
			// checkBox3
			// 
			this.checkBox3.AutoSize = true;
			this.checkBox3.Location = new System.Drawing.Point(325, 41);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new System.Drawing.Size(67, 19);
			this.checkBox3.TabIndex = 1;
			this.checkBox3.Text = "开关3";
			this.checkBox3.UseVisualStyleBackColor = true;
			// 
			// checkBox2
			// 
			this.checkBox2.AutoSize = true;
			this.checkBox2.Location = new System.Drawing.Point(246, 41);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(67, 19);
			this.checkBox2.TabIndex = 1;
			this.checkBox2.Text = "开关2";
			this.checkBox2.UseVisualStyleBackColor = true;
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Location = new System.Drawing.Point(167, 41);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(67, 19);
			this.checkBox1.TabIndex = 1;
			this.checkBox1.Text = "开关1";
			this.checkBox1.UseVisualStyleBackColor = true;
			// 
			// qdFrameComboBox
			// 
			this.qdFrameComboBox.FormattingEnabled = true;
			this.qdFrameComboBox.Items.AddRange(new object[] {
            "标准",
            "动感",
            "商务",
            "抒情",
            "清洁",
            "柔和",
            "激情",
            "明亮",
            "浪漫",
            "演出",
            "暂停",
            "全关",
            "全开",
            "全开关",
            "电影",
            "备用1",
            "备用2",
            "备用3",
            "备用4",
            "备用5",
            "备用6",
            "摇麦",
            "喝彩",
            "倒彩"});
			this.qdFrameComboBox.Location = new System.Drawing.Point(23, 39);
			this.qdFrameComboBox.Name = "qdFrameComboBox";
			this.qdFrameComboBox.Size = new System.Drawing.Size(99, 23);
			this.qdFrameComboBox.TabIndex = 0;
			this.qdFrameComboBox.SelectedIndexChanged += new System.EventHandler(this.qdFrameComboBox_SelectedIndexChanged);
			// 
			// label36
			// 
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(26, 21);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(112, 15);
			this.label36.TabIndex = 9;
			this.label36.Text = "主场景播放方式";
			// 
			// frame0methodComboBox
			// 
			this.frame0methodComboBox.FormattingEnabled = true;
			this.frame0methodComboBox.Items.AddRange(new object[] {
            "固定时间",
            "固定次数"});
			this.frame0methodComboBox.Location = new System.Drawing.Point(21, 51);
			this.frame0methodComboBox.Name = "frame0methodComboBox";
			this.frame0methodComboBox.Size = new System.Drawing.Size(116, 23);
			this.frame0methodComboBox.TabIndex = 10;
			// 
			// GlobalSetForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(926, 731);
			this.Controls.Add(this.qdGroupBox);
			this.Controls.Add(this.dmxGroupBox);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "GlobalSetForm";
			this.Text = "全局设置";
			this.Load += new System.EventHandler(this.GlobalSetForm_Load);
			this.dmxGroupBox.ResumeLayout(false);
			this.skGroupBox.ResumeLayout(false);
			this.skGroupBox.PerformLayout();
			this.zuheGroupBox.ResumeLayout(false);
			this.zuheGroupBox.PerformLayout();
			this.zuheEnableGroupBox.ResumeLayout(false);
			this.zuheEnableGroupBox.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.frame0numericUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.frame4numericUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.frame3numericUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.frame2numericUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.frame1numericUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.circleTimeNumericUpDown)).EndInit();
			this.groupBox7.ResumeLayout(false);
			this.groupBox7.PerformLayout();
			this.qdGroupBox.ResumeLayout(false);
			this.qdGroupBox.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox dmxGroupBox;
		private System.Windows.Forms.GroupBox qdGroupBox;
		private System.Windows.Forms.Button qdSaveButton;
		private System.Windows.Forms.CheckBox[] qdCheckBoxes = new System.Windows.Forms.CheckBox[8];
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.CheckBox checkBox3;
		private System.Windows.Forms.CheckBox checkBox4;
		private System.Windows.Forms.CheckBox checkBox5;
		private System.Windows.Forms.CheckBox checkBox6;
		private System.Windows.Forms.CheckBox checkBox7;
		private System.Windows.Forms.CheckBox checkBox8;
		private System.Windows.Forms.ComboBox qdFrameComboBox;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.Button globalSaveButton;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox startupComboBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox tongdaoCountComboBox;
		private System.Windows.Forms.GroupBox zuheGroupBox;
		private System.Windows.Forms.CheckBox zuheCheckBox;
		private System.Windows.Forms.GroupBox zuheEnableGroupBox;
		private System.Windows.Forms.ComboBox zuheFrameComboBox;
	
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.NumericUpDown circleTimeNumericUpDown;

		private System.Windows.Forms.GroupBox skGroupBox;
		private System.Windows.Forms.Button frameSaveButton;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.ComboBox[] skComboBoxes = new System.Windows.Forms.ComboBox[24];
		private System.Windows.Forms.ComboBox skComboBox1;
		private System.Windows.Forms.ComboBox skComboBox2;
		private System.Windows.Forms.ComboBox skComboBox3;
		private System.Windows.Forms.ComboBox skComboBox4;
		private System.Windows.Forms.ComboBox skComboBox5;
		private System.Windows.Forms.ComboBox skComboBox6;
		private System.Windows.Forms.ComboBox skComboBox7;
		private System.Windows.Forms.ComboBox skComboBox8;
		private System.Windows.Forms.ComboBox skComboBox9;
		private System.Windows.Forms.ComboBox skComboBox10;
		private System.Windows.Forms.ComboBox skComboBox11;
		private System.Windows.Forms.ComboBox skComboBox12;
		private System.Windows.Forms.ComboBox skComboBox13;
		private System.Windows.Forms.ComboBox skComboBox14;
		private System.Windows.Forms.ComboBox skComboBox15;
		private System.Windows.Forms.ComboBox skComboBox16;
		private System.Windows.Forms.ComboBox skComboBox17;
		private System.Windows.Forms.ComboBox skComboBox18;
		private System.Windows.Forms.ComboBox skComboBox19;
		private System.Windows.Forms.ComboBox skComboBox20;
		private System.Windows.Forms.ComboBox skComboBox21;
		private System.Windows.Forms.ComboBox skComboBox22;
		private System.Windows.Forms.ComboBox skComboBox23;
		private System.Windows.Forms.ComboBox skComboBox24;
		private System.Windows.Forms.Button skSaveButton;
		private System.Windows.Forms.Label label34;

		private System.Windows.Forms.ComboBox[] frameComboBoxes = new System.Windows.Forms.ComboBox[4];
		private System.Windows.Forms.ComboBox frame4ComboBox;
		private System.Windows.Forms.ComboBox frame2ComboBox;
		private System.Windows.Forms.ComboBox frame1ComboBox;
		private System.Windows.Forms.ComboBox frame3ComboBox;
		private System.Windows.Forms.NumericUpDown frame0numericUpDown;
		private System.Windows.Forms.NumericUpDown[] frameNumericUpDowns = new System.Windows.Forms.NumericUpDown[4];
		private System.Windows.Forms.NumericUpDown frame4numericUpDown;
		private System.Windows.Forms.NumericUpDown frame3numericUpDown;
		private System.Windows.Forms.NumericUpDown frame2numericUpDown;
		private System.Windows.Forms.NumericUpDown frame1numericUpDown;
		private System.Windows.Forms.ComboBox[] frameMethodComboBoxes = new System.Windows.Forms.ComboBox[4];
		private System.Windows.Forms.ComboBox frame4methodComboBox;
		private System.Windows.Forms.ComboBox frame3methodComboBox;
		private System.Windows.Forms.ComboBox frame2methodComboBox;
		private System.Windows.Forms.ComboBox frame1methodComboBox;
		private System.Windows.Forms.Label label35;
		private System.Windows.Forms.ComboBox frame0methodComboBox;
		private System.Windows.Forms.Label label36;
	}
}